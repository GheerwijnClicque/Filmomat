$(function() {
	function str_pad_left(string,pad,length) {
	    return (new Array(length+1).join(pad)+string).slice(-length);
	}

    // Socket IO
    var socket = io.connect('http://localhost:3000');

    var duration = 0;
    var start = Date.now(), diff, minutes, seconds, interv, interval;
    var int = 0;
    var string = "";

	// progress circle
	var context = document.getElementById('progressBarCanvas').getContext('2d');
	var al = 0; // amount loaded
	var startCircle = 4.72;
	var cw = context.canvas.width;
	var ch = context.canvas.height;
	var difference;

    socket.on('step', function(data) {
        if(data.message) {
            // $('#comment').text(data.message);
            // console.log(data.message.desc);
			$('#step').text('Executing "' + data.message.desc + '"');

            var counter = new Countdown({
                seconds:  data.message.time,  // number of seconds to count down
                onUpdate: function(sec) {
                    // console.log(Math.round(sec));
					var minutes = Math.floor(Math.round(sec) / 60);
					var seconds = Math.round(sec) - (minutes * 60);
					$('#time').text(str_pad_left(minutes,'0',2)+':'+str_pad_left(seconds,'0',2));
					progressBar();
                }, // callback for each second
                done: function() { console.log('counter ended!'); } // final action
            });

            counter.start();
        }
        else {
            console.log('there is a problem: ', data.message);
        }
    });

    socket.on('processDone', function(data) {
        console.log('done: ' + data.state);
        if(data.state) {
            // $('#comment').text(data.message);
            console.log('process finished');
			$('#time').text('process finished');
        }
        else {
            console.log('there is a problem: ', data.message);
        }
    });

    String.prototype.toSeconds = function () {
    	if (!this) return null;
    	var time = this.split(':');
    	return (+time[0]) * 60 + (+time[1] || 0);
    };



	var progressBar = function() {
		difference = ((al / 100) * Math.PI*2*10).toFixed(2);
		context.clearRect(0,  0, cw, ch);
		context.lineWidth = 10;
		context.fillStyle = '#09F';
		context.strokeStyle = '#09F';
		context.textAlign = 'center';
		context.fillText(al + '%', cw*0.5, ch*0.5+2, cw);
		context.beginPath();
		context.arc(35, 35, 30, startCircle, difference/10+startCircle, false);
		context.stroke();

		al++;
	};





});

function Countdown(options) {
  var timer,
  instance = this,
  seconds = options.seconds || 10,
  updateStatus = options.onUpdate || function () {},
  counterEnd = options.done || function () {};

  function decrementCounter() {
    updateStatus(seconds);
    if (Math.round(seconds) <= 0) {
      counterEnd();
      instance.stop();
    }
    seconds -= 0.25;
  }

  this.start = function () {
    clearInterval(timer);
    timer = 0;
    seconds = options.seconds;
    timer = setInterval(decrementCounter, 250);
  };

  this.stop = function () {
    clearInterval(timer);
  };
}
